import logo from './logo.svg';
import './App.css';

import { OnlineShopping } from './Components/OnlineShopping';

function App() {
  return (
    <div>
      <OnlineShopping></OnlineShopping>
      </div>
  );
}

export default App;