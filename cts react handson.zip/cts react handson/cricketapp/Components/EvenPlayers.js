import React from 'react'

function EvenPlayers([,Second,,Fourth,,Sixth]) {
    return (
        <div>
            <ul>
            <li>Second:{Second}</li>
            <li>Fourth: {Fourth}</li>
            <li>Sixth: {Sixth}</li>
            </ul>
        </div>
    )
}
export {EvenPlayers}