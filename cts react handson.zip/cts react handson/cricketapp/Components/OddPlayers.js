import React from 'react'

function OddPlayers([First,,Third,,Fifth]) {
    return (
        <div>
            <ul>
            <li>First: {First}</li>
            <li>Third: {Third}</li>
            <li>Fifth: {Fifth}</li>
            </ul>
            
        </div>
    )
}
export {OddPlayers}