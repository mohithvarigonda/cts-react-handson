import logo from './logo.svg';
import './App.css';
import {Office} from './Components/Office';

function App() {
  return (
    <div className="App">
      <Office></Office>
    </div>
  );
}

export default App;
